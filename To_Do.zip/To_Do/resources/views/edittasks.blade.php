
@extends('parent')
@section('content')
<div class="title" style="color:brown;">This is the Gallery Section</div>
 @endsection  
