<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>CloserWalk | About</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="{{ URL::asset('css/style.css') }}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{ URL::asset('css/coin-slider.css') }}" />
<script type="text/javascript" src="{{ URL::asset('js/cufon-yui.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/droid_sans_400-droid_sans_700.font.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/jquery-1.4.2.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/script.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/coin-slider.min.js') }}"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li><a href="{{ url('/') }}"><span>Home Page</span></a></li>
          <li><a href="{{ url('/support') }}"><span>Support</span></a></li>
          <li class="active"><a href="{{ url('/about') }}"><span>About Us</span></a></li>
          <li><a href="{{ url('/blog') }}"><span>Blog</span></a></li>
          <li><a href="{{ url('/contact') }}"><span>Contact Us</span></a></li>
        </ul>
      </div>
      <div class="clr"></div>
      <div class="logo">
        <h1><a href="{{ url('/') }}">Closer<span>       Walk</span></a></h1>
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="960" height="360" alt="" /> </a> <a href="#"><img src="images/slide2.jpg" width="960" height="360" alt="" /> </a> <a href="#"><img src="images/slide3.jpg" width="960" height="360" alt="" /> </a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Get To</span> Know Us</h2>
          <div class="clr"></div>
          <p><strong>We at Closer walk are an evangelism unit that is equipped for propagating the gospel all around the globe.
          </strong></p>
        </div>
        <div class="article">
          <h2><span>Our</span> Mission</h2>
          <div class="clr"></div>
          <p><strong> Our sole mission is to ensure that the gospel reaches all corners of the earth. We are taking Jesus to the world.</strong></p>
          <p>How is your Christian walk? Let us help you draw closer to the Maker.</p>
        </div>
      </div>
      <div class="sidebar">
        <div class="searchform">
          <form id="formsearch" name="formsearch" method="post" action="#">
            <span>
            <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
            </span>
            <input name="button_search" src="images/search.gif" class="button_search" type="image" />
          </form>
        </div>
        <div class="clr"></div>
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="#">Home</a></li>
            <li><a href="#">Blog</a></li>
          </ul>
        </div>
        <div class="gadget">
          <div class="clr"></div>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        <h2><span>Image</span> Gallery</h2>
        <a href="#"><img src="images/gal1.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal2.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal3.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal4.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal5.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal6.jpg" width="75" height="75" alt="" class="gal" /></a> </div>
      <div class="col c2">
        <ul class="fbg_ul">
          <li><a href="#"></a></li>
        </ul>
      </div>
      <div class="col c3">
        <h2><span>Contact</span> Us</h2>
        <p>We would love to hear from you!</p>
        <p class="contact_info"> <span>Address:</span> 789/8 Ayensu Road,Oyibi,Accra<br />
          <span>Telephone:</span> +233-2645-3245325<br />
          <span>E-mail:</span> <a href="#">closerwalk@gmail.com</a> </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Princess' Blog</a>.</p>
      <p class="rf">Design by Gidi <a href="http://www.dreamtemplate.com/">Princess</a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
</body>
</html>
