@extends('header')
@section('begin')
<div class="row">
<div class="container">
    <script type="text/javascript">
        $('#alert').hide(5000);
    </script>
           <div id="alert"  class="alert alert-info" style="margin-top:5px;">
               <a href="#" class="close" data-dismiss="alert" aria-label="close"><span class='glyphicon glyphicon-remove-circle'></span></a>
  <strong>Hello There</strong> {{$message}}
            </div>    
    <div style="margin-top:10px;" class="jumbotron">
        
        {!! Form::open(array('route'=>'create.store')) !!}
        <div class="form-group" {!! $errors->has('name')? "has-error":"" !!}>
        {!! Form::label('task_name','Name of Task') !!}
        {!! Form::text('name', null,['class'=>'form-control']) !!}
        {!! $errors->first('name', '<span class="help-inline">:message</span>') !!}
        </div>
        <div class="form-group" {!! $errors->has('description')? "has-error":"" !!}>
        {!! Form::label('desc','Description') !!}
        {!! Form::textarea('description',null,['class'=>'form-control']) !!}

            {!! $errors->first('description', '<span class="help-block">:message</span>') !!}

            {!! Form::submit('save',['class'=>'form-control btn btn-primary col-sm-offset']) !!}
        </div>
        {!! Form::close() !!}
        
               </div>

    
    </div>
</div>
 @endsection  
