<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>CloserWalk</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link href="{{ URL::asset('css/style.css') }}" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" type="text/css" href="{{ URL::asset('css/coin-slider.css') }}" />
  <script type="text/javascript" src="{{ URL::asset('js/cufon-yui.js') }}"></script>
  <script type="text/javascript" src="{{ URL::asset('js/droid_sans_400-droid_sans_700.font.js') }}"></script>
  <script type="text/javascript" src="{{ URL::asset('js/jquery-1.4.2.min.js') }}"></script>
  <script type="text/javascript" src="{{ URL::asset('js/script.js') }}"></script>
  <script type="text/javascript" src="{{ URL::asset('js/coin-slider.min.js') }}"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li class="active"><a href="{{ url('/') }}"><span>Home Page</span></a></li>
          <li><a href="{{ url('/support') }}"><span>Support</span></a></li>
          <li><a href="{{ url('/about') }}"><span>About Us</span></a></li>
          <li><a href="{{ url('/blog') }}"><span>Blog</span></a></li>
          <li><a href="{{ url('/contact') }}"><span>Contact Us</span></a></li>
        </ul>
      </div>
      <div class="clr"></div>
      <div class="logo">
        <h1><a href="{{ url('/') }}">Closer<span>       Walk</span></a></h1>
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="960" height="360" alt="" /> </a> <a href="#"><img src="images/slide2.jpg" width="960" height="360" alt="" /> </a> <a href="#"><img src="images/slide3.jpg" width="960" height="360" alt="" /> </a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Christianity </span>Today </h2>
          <p class="infopost">Posted <span class="date">on 12 April 2017</span> by <a href="#">Gidi</a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> &nbsp;&nbsp; <a href="#" class="com">Comments <span>11</span></a></p>
          <div class="clr"></div>
          <div class="img"><img src="images/slide2.jpg" width="620" height="154" alt="" class="fl" /></div>
          <div class="post_content">
            <p>When you ask someone about their faith, expect to hear a qualifier.

              Of course, there’s “spiritual but not religious,” a category that 11 percent of Americans now fall into, according to Barna Group research. (The figure could be at least double that if applied to all without a particular religious affiliation, often referred to as the “nones.”)

              But even Christianity comes with caveats. Some try to change up the term by saying, “I’m not a Christian, but a Christ-follower.”

              #ImChristianBut trended on Twitter a couple years ago, in the wake of a BuzzFeed video of young Christians butting against what they saw as negative stereotypes of Christians. They said lines like “I’m Christian, but I’m not homophobic” and “I’m Christian, but I’m not closed-minded.”

              Before that, the spoken word poem “Why I Hate Religion, But Love Jesus” took off with a message that confronted frustrations with religious legalism. It now has 32 million YouTube views.

              A new report by Barna adds another label to the buts: those who “love Jesus, but not the church.” They’re Christians who say their faith is important to them, but haven’t attended church in six months or more.</p>

            <p class="spec"><a href="#" class="rm">Read more...</a></p>
          </div>
          <div class="clr"></div>
        </div>
          <div class="clr"></div>
          <div class="img"><img src="images/slide3.jpg" width="620" height="154" alt="" class="fl" /></div>


          </div>
          <div class="clr"></div>
        </div>
        <p class="pages"><small>Page 1 of 2</small> <span>1</span> <a href="#">2</a> <a href="#">&raquo;</a></p>
      </div>
      <div class="sidebar">
        <div class="searchform">
          <form id="formsearch" name="formsearch" method="post" action="#">
            <span>
            <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
            </span>
            <input name="button_search" src="images/search.gif" class="button_search" type="image" />
          </form>
        </div>
        <div class="clr"></div>
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="#">Home</a></li>
            <li><a href="#">Blog</a></li>
          </ul>
        </div>

      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        <h2><span>Image</span> Gallery</h2>
        <a href="#"><img src="images/gal1.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal2.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal3.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal4.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal5.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal6.jpg" width="75" height="75" alt="" class="gal" /></a> </div>
      <div class="col c2">
      </div>
      <div class="col c3">

      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Princess' Blog</a>.</p>
      <p class="rf">Design by Gidi <a href="http://www.dreamtemplate.com/">Princess</a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
</body>
</html>
