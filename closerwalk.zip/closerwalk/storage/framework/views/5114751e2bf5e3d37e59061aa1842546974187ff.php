<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>CloserWalk | Blog</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/droid_sans_400-droid_sans_700.font.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="menu_nav">
        <ul>
          <li><a href="<?php echo e(url('/')); ?>"><span>Home Page</span></a></li>
          <li><a href="<?php echo e(url('/support')); ?>"><span>Support</span></a></li>
          <li ><a href="<?php echo e(url('/about')); ?>"><span>About Us</span></a></li>
          <li class="active"><a href="<?php echo e(url('/blog')); ?>"><span>Blog</span></a></li>
          <li><a href="<?php echo e(url('/contact')); ?>"><span>Contact Us</span></a></li>
        </ul>
      </div>
      <div class="clr"></div>
      <div class="logo">
        <h1><a href="<?php echo e(url('/')); ?>">Closer<span>       Walk</span></a></h1>
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider"> <a href="#"><img src="images/slide1.jpg" width="960" height="360" alt="" /> </a> <a href="#"><img src="images/slide2.jpg" width="960" height="360" alt="" /> </a> <a href="#"><img src="images/slide3.jpg" width="960" height="360" alt="" /> </a> </div>
        <div class="clr"></div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>A Blog</span> Entry</h2>
          <div class="clr"></div>
          <p>Posted by <a href="#">Enyonam</a> <span>&nbsp;&bull;&nbsp;</span> Filed under <a href="#">lit</a>, <a href="#"></a></p>
          <p>When we talk about evangelism we tend to use words like “share” and “spread” and even “explosion.” It’s no coincidence that all of these words suggest momentum. The gospel always moves with a sense of excitement, as people who have seen its transforming power can’t help but share the Good News.

            As the Billy Graham Distinguished Chair at Wheaton College in Wheaton, Ill, Dr. Ed Stetzer now serves as executive director of Wheaton’s Billy Graham Center for Evangelism (BGCE) as chair of the Evangelism & Leadership Program in the Wheaton College Graduate School and as publisher of Evangelical Missions Quarterly. In these roles, he is ﬁrsthand witness to the ways the momentum surrounding the gospel accomplishes great things, both around the school and within the organization he leads. Previously, he served as executive director of LifeWay Research.

            Laura Leonard spoke with Stetzer about his leadership role, about momentum he’s seeing around the spread of the gospel worldwide and about building and maintaining momentum as an organizational leader.

            Tell me about your role at Wheaton and the work of the BGCE.

            I hold the Billy Graham Distinguished Chair for Church, Mission, and Evangelism at Wheaton College, so I teach, write and do research on church and culture to better prepare people to engage the cultural moment we’re in. Part of that role includes the Billy Graham Center for Evangelism, which does conferences and training. It also includes a series of institutes, from the Institute for Prison Ministries to church evangelism initiatives, so there are several different initiatives that ﬁt under that as well.

            What momentum are you seeing as it relates to the advance of the mission and gospel worldwide?

            Of course it depends on where around the world. I certainly think we’re in a season when people are rediscovering the importance of showing and sharing the love of Jesus in the midst of a broken and hurting world. I think that in the majority world, we see the advance of the gospel is pretty substantive; the last century has been a remarkable season of growth for Christianity around the world, primarily in the southern hemisphere. But now, as we’re seeing a need to in a sense re-evangelize the West, we’re seeing a greater sense of passion and mission to be about that here as well.

            What signs of hope are you seeing for the worldwide church?

            We just did a research project in Brazil with Lifeway Research (I’m no longer there, but I am still writing on that project) and there will be more evangelicals in Brazil than in the United States by 2050. That’s pretty remarkable growth. In the United States, church planting and its rapid growth — we’re planting 4,000 churches a year, which is more than we’re closing — that’s a pretty remarkable shift forward for the church.

            How does a leader build momentum within an organization?

            That forward movement is central to what we do. We seek to have a common goal, to have a common direction, to rally for a common mission. I like Eugene Peterson’s line about discipleship: He calls it “long obedience in the same direction.” Signiﬁcant ministry impact comes from long focus in the same direction. Ultimately that focus and faithfulness builds momentum, and that continues the momentum forward.

            This interview originally appeared in the Spring 2017 issue of Outcomes Magazine, a publication of the Christian Leadership Alliance.</p>
          <p>Tagged: <a href="#">faith</a>, <a href="#">work</a>, <a href="#"></a>, <a href="#"></a></p>
          <p><a href="#"><strong>Comments (3)</strong></a> <span>&nbsp;&bull;&nbsp;</span> April 12, 2017 <span>&nbsp;&bull;&nbsp;</span> <a href="#"><strong>Edit</strong></a></p>
        </div>
        <div class="article">
          <h2><span>3</span> Responses</h2>
          <div class="clr"></div>
          <div class="comment"> <a href="#"><img src="images/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
            <p><a href="#">admin</a> Says:<br />
              April 12,2017 at 2:17 pm</p>
            <p>Helpful. Thanks.</p>
          </div>
          <div class="comment"> <a href="#"><img src="images/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
            <p><a href="#">Admin</a> Says:<br />
              April 12, 2017 at 3:21 pm</p>
            <p>Aspire and Achieve.</p>
          </div>
          <div class="comment"> <a href="#"><img src="images/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
            <p><a href="#">admin</a> Says:<br />
              April 20th, 2009 at 2:17 pm</p>
            <p>The Lord will strenghthen you.</p>
          </div>
        </div>
        <div class="article">
          <h2><span>Leave a</span> Reply</h2>
          <div class="clr"></div>
          <form action="#" method="post" id="leavereply">
            <ol>
              <li>
                <label for="name">Name (required)</label>
                <input id="name" name="name" class="text" />
              </li>
              <li>
                <label for="email">Email Address (required)</label>
                <input id="email" name="email" class="text" />
              </li>
              <li>
                <label for="website">Website</label>
                <input id="website" name="website" class="text" />
              </li>
              <li>
                <label for="message">Your Message</label>
                <textarea id="message" name="message" rows="8" cols="50"></textarea>
              </li>
              <li>
                <input type="image" name="imageField" id="imageField" src="images/submit.gif" class="send" />
                <div class="clr"></div>
              </li>
            </ol>
          </form>
        </div>
      </div>
      <div class="sidebar">
        <div class="searchform">
          <form id="formsearch" name="formsearch" method="post" action="#">
            <span>
            <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
            </span>
            <input name="button_search" src="images/search.gif" class="button_search" type="image" />
          </form>
        </div>
        <div class="clr"></div>
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="#">Home</a></li>
            <li><a href="#">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="fbg">
    <div class="fbg_resize">
      <div class="col c1">
        <h2><span>Image</span> Gallery</h2>
        <a href="#"><img src="images/gal1.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal2.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal3.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal4.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal5.jpg" width="75" height="75" alt="" class="gal" /></a> <a href="#"><img src="images/gal6.jpg" width="75" height="75" alt="" class="gal" /></a> </div>
      <div class="col c2">
        <p></p>
        <ul class="fbg_ul">
        </ul>
      </div>
      <div class="col c3">
        <h2><span>Contact</span> Us</h2>
        <p class="contact_info"> <span>Address:</span> 767/7 Ayensu Street,Oyibi,Accra<br />
          <span>Telephone:</span> +233-5756-7564<br />
          <span>E-mail:</span> <a href="#">closerwalk@gmail.com</a> </p>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright <a href="#">Princess' Blog</a>.</p>
      <p class="rf">Design by Gidi <a href="http://www.dreamtemplate.com/">Princess</a></p>
      <div style="clear:both;"></div>
    </div>
  </div>
</div>
</body>
</html>
