
<nav>
<div class="nav navbar-default">
<div class="container-fluid">
   
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#index-navbar1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="{{route('all.index')}}">
        Contact Directory
        </a>
       </div>
         <!-- Collect the nav links for toggling -->
    <div class="collapse navbar-collapse " id="index-navbar1">
      <ul class="nav navbar-nav">
        <li role=presentation><a href="{{route('all.index')}}"><span class="glyphicon glyphicon-home"></span>All Task</a></li>
        <li role="presentation"><a href="{{route('create.create')}}"><span class="glyphicon glyphicon-plus"></span>Create Task</a></li>
       
        </ul>
        
        <ul class="nav navbar-nav navbar-right  ">
            <li><a data-toggle="modal" data-target="#loginModal"><span class="glyphicon glyphicon-log-in"></span>Log In</a></li>
            
            <li><a href="signup.php" role="button" class="btn btn-info"><span class="glyphicon glyphicon-user"></span>Register</a></li>
        </ul>
    </div><!-- /.navbar-collapse -->   
    
        </div>    
    
    
    </div>
    
</nav>


