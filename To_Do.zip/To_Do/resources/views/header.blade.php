<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />    
<title>Laravel try</title>
   
<meta name="HandheldFriendly" content="True" />
<meta name="MobileOptimized" content="320" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="description" content="trying" />

    <link rel="stylesheet" type="text/css" href="{{ URL:: asset('bootstrap-3.3.6-dist/css/bootstrap-theme.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ URL:: asset('bootstrap-3.3.6-dist/css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ URL:: asset('bootstrap/css/bootstrap-responsive.min.css') }}">

    <script src="{{ URL::asset('js/jquery.js') }}" type="text/javascript" ></script>
    <script src="{{ URL::asset('js/bootstrap.js') }}" type="text/javascript" ></script>
    <script src="{{ URL::asset('js/custom.js') }}" type="text/javascript" ></script>


</head>
<body>     
@include('navigation')    

<div class="row-sm-12">    
 @yield('begin')  
  </div>  
</body>    
</html>
 