@extends('header')
@section('begin')

 @if(Session::has('msg_creation'))
 <div class="alert alert-success">{{Session('msg_creation')}}</div>
@endif
 @if(Session::has('msg_update'))
     <div class="alert alert-info">{{Session('msg_update')}}</div>
 @endif
 @if(Session::has('msg_delete'))
     <div class="alert alert-danger">{{Session('msg_delete')}}</div>
 @endif

    <table class="table-responsive table-responsive">
        <thead>
        <tr>
            <th>Name:</th>
            <th >Description:</th>
            <th class="info">View:</th>
            <th class="warning">Edit</th>
            <th class="danger">Delete</th>
        </tr>
        </thead>
        <tbody>
        @foreach($task as tasks)
        <tr>
           <td>{{$tasks->name_of_task}}</td>
           <td>{{$tasks->descrition}}</td>
        </tr>
         @endforeach
        </tbody>
    </table>
 @endsection

